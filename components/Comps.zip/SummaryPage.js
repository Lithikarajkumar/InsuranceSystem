import React, { useState, useEffect } from 'react';
import { useAuth } from './AuthContext'; // Import useAuth from AuthProvider
import {useLocation, useNavigate } from 'react-router-dom';
import './SummaryPage.css'; // Add your custom CSS here

function SummaryPage() {
  
  const [proposals, setProposals] = useState([]);
  const location = useLocation();
  const navigate = useNavigate();
  const { authState,selectedPlan } = location.state || {}; // Extract authState from location.state


  useEffect(() => {
    const fetchProposals = async () => {
        try {
            // Ensure authState and userInfo are available
            if (!authState || !authState.userInfo) {
                console.error('Auth state or userInfo is missing');
                navigate('/signin'); // Redirect to signin if authState is not defined
                return;
            }

            const userId = authState.userInfo._id; // Safely access _id from userInfo
            console.log('User ID:', userId); // Check if userId is properly retrieved

            const response = await fetch(`http://localhost:5000/proposals/user/${userId}`);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();
            setProposals(data);
        } catch (error) {
            console.error('Error fetching proposals:', error);
        }
    };

    fetchProposals();
}, [authState, navigate]); // Add authState and navigate as dependencies


  // Filter proposals based on the selected plan
  const filteredProposals = selectedPlan
    ? proposals.filter(proposal => proposal.planDetails.name === selectedPlan.name) // Adjust based on the structure of selectedPlan
    : proposals;

  return (
    <div className='summary-page'>
      <h2>Your Proposals</h2>
      {filteredProposals.length > 0 ? (
        <table className='proposals-table'>
          <thead>
            <tr>
              <th>Plan</th>
              <th>Premium</th>
              <th>Proposer Name</th>
              <th>Nominee Name</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {filteredProposals.map(proposal => (
              <tr key={proposal._id}>
                <td>{proposal.planDetails.name}</td>
                <td>{proposal.calculatedPremium}</td>
                <td>{proposal.proposerDetails.name}</td>
                <td>{proposal.nomineeDetails.nomineeFullName}</td>
                <td>{proposal.status || 'Pending'}</td> {/* Display status if available */}
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No proposals found.</p>
      )}
    </div>
  );
}

export default SummaryPage;